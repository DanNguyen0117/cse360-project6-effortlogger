package application;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.stage.Stage;

public class LogsController {
	private Stage stage;
	private Scene scene;
	private Parent root;
	private String access;
	private String choice;
	private String Formatted = "";
	private String Formatted2 = "";
	private ObservableList<String> data = FXCollections.observableArrayList();
	@FXML
	private ChoiceBox<String> Project;
	@FXML
	private Label Log;
	@FXML
	private Button Select;
	@FXML
	private Button Return;
	@FXML
	private Label Log1;
	@FXML
	private Label Total;
	@FXML
	private Label Total1;
	@FXML
	private void initialize() {	
		try {
			Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/effortloggerbase", "root", "root");//Establishing connection
			System.out.println("Connected With the database successfully");
			String insertQuery = "SELECT EFFORTLOG FROM table1";
			 try (PreparedStatement preparedStatement = connection.prepareStatement(insertQuery);
	                 ResultSet resultSet = preparedStatement.executeQuery()) {
	                while (resultSet.next()) {
	                    String choice = resultSet.getString("EFFORTLOG");
	                    data.add(choice);
	                }
	                preparedStatement.close();
	                connection.close();
	            }
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("Error while connecting to the database");
			}
		Project.setItems(data);
	}
	public void Select(ActionEvent event) throws IOException {
		choice = Project.getValue();
		Total.setText("Total Project Entries: " + HighestIndex(choice));
		Total1.setText("Total Defect Entries: " + HighestNumber(choice));
		try {
			Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/effortloggerbase", "root", "root");//Establishing connection
			System.out.println("Connected With the database successfully");
			String insertQuery = "SELECT IndexNum, curDate, StartTime, StopTime, TimeDelta, LifeCycleStep, Category, Deliverable FROM table2 WHERE EFFORTLOG = ?";
			String insertQuery2 = "SELECT Number, Name, Detail, Injected, Removed, DefCat, Status, Fix FROM table2 WHERE EFFORTLOG = ? AND Number IS NOT NULL";
			PreparedStatement preparedStatement = connection.prepareStatement(insertQuery);
			PreparedStatement preparedStatement2 = connection.prepareStatement(insertQuery2);
			preparedStatement.setString(1, choice);
			preparedStatement2.setString(1, choice);
			try (ResultSet resultSet = preparedStatement.executeQuery()) {
                	for(int i = 0; i < HighestIndex(choice); i++) {
                        resultSet.next();
                        Formatted = Formatted + (resultSet.getString("IndexNum") + ". " + resultSet.getString("curDate") + " " + resultSet.getString("StartTime") + "-" + 
                        resultSet.getString("StopTime") + "; " + resultSet.getString("TimeDelta") + 
                        "; " + resultSet.getString("LifeCycleStep") + "; " + resultSet.getString("Category") + "; " + resultSet.getString("Deliverable") + "\n");
                	}
			}
			try (ResultSet resultSet1 = preparedStatement2.executeQuery()) {
				for(int i = 0; i < HighestNumber(choice); i++) {
                    resultSet1.next();
                    Formatted2 = Formatted2 + (resultSet1.getString("Number") + ". " + resultSet1.getString("Name") + " " + resultSet1.getString("Detail") + " " + 
                    resultSet1.getString("Injected") + "-" + resultSet1.getString("Removed") + 
                    "; " + resultSet1.getString("DefCat") + "; " + resultSet1.getString("Status") + "; " + resultSet1.getString("Fix") + "\n");
            	}
			}
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("Error while connecting to the database");
			}
		Log.setText(Formatted);
		Log1.setText(Formatted2);
	}
	public int HighestIndex(String curProject) {
		int maxIndex = 0;
		try {
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/effortloggerbase", "root", "root");
            String insertQuery = "SELECT MAX(IndexNum) AS maxIndex FROM table2 WHERE EFFORTLOG = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(insertQuery);
            preparedStatement.setString(1, curProject);
            ResultSet resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                maxIndex = resultSet.getInt("maxIndex");
            }
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("Error while connecting to the database");
			}
		return maxIndex;
	}
	public int HighestNumber(String curProject) {
		int maxNumber = 0;
		try {
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/effortloggerbase", "root", "root");
            String insertQuery = "SELECT MAX(Number) AS maxNumber FROM table2 WHERE EFFORTLOG = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(insertQuery);
            preparedStatement.setString(1, curProject);
            ResultSet resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                maxNumber = resultSet.getInt("maxNumber");
            }
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("Error while connecting to the database");
			}
		return maxNumber;
	}
	public void Return(ActionEvent event) throws IOException {
		Parent root = FXMLLoader.load(getClass().getResource("/EffortLogger1.fxml"));
		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	}
	
}
