package application;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class CreateController {
	private Stage stage;
	private Scene scene;
	private Parent root;
	private String access;
	@FXML
	private Button Create;
	@FXML
	private TextField myTextField;
	@FXML
	private TextField pasTextField;
	@FXML
	private TextField pasTextField1;
	public void switchToScene2(ActionEvent event) throws IOException {
	try {
		Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/effortloggerbase", "root", "root");//Establishing connection
		System.out.println("Connected With the database successfully");
		String insertQuery = "INSERT INTO table3 (Username, Password) VALUES (?, ?)";
        PreparedStatement preparedStatement = connection.prepareStatement(insertQuery);
        preparedStatement.setString(1 , myTextField.getText());
        preparedStatement.setString(2 , pasTextField.getText());
        preparedStatement.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("Error while connecting to the database");
		}
			Parent root = FXMLLoader.load(getClass().getResource("/LoginScreen.fxml"));
			stage = (Stage)((Node)event.getSource()).getScene().getWindow();
			scene = new Scene(root);
			stage.setScene(scene);
			stage.show();
	}
}

