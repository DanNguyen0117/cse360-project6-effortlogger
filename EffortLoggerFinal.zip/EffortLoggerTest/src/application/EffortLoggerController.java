package application;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.paint.Color;
import javafx.scene.shape.Shape;
import javafx.stage.Stage;
import java.sql.*;

public class EffortLoggerController {
	private int indexNum;
	private long startTime;
	private long stopTime;
    private Label time;
    private Label date;
    private Stage stage;
	private Scene scene;
	private Parent root;
	private String access;
	ObservableList<String> Project = FXCollections.observableArrayList();
	ObservableList<String> LifeCycle = FXCollections.observableArrayList("Planning","Information Gathering","Information Understanding", "Verifying", "Outlining", "Drafting", "Finalizing", "Team Meeting", "Coach Meeting", "Stakeholder Meeting");
	ObservableList<String> EffortCategory = FXCollections.observableArrayList("Plans","Deliverables","Interuptions","Defects","Others");
	ObservableList<String> Plan = FXCollections.observableArrayList("Project Plan","Risk Management Plan","Conceptual Design Plan", "Detailed Design Plan", "Implementation Plan");
	@FXML
	private Button StartAnActivity;
	@FXML
	private Button ReturntoStart;
	@FXML 
	private Label Clock1;
	@FXML
	private Shape Rectangle1;
	@FXML 
	private Button ProceedToDefect;
	@FXML
	private Button ProceedToEditor;
	@FXML
	private Button StopActivity;
	@FXML
	private Button Logs;
	@FXML
	private ChoiceBox<String> ProjectBox;
	@FXML
	private ChoiceBox<String> LifeCycleBox;
	@FXML
	private ChoiceBox<String> EffortCategoryBox;
	@FXML
	private ChoiceBox<String> PlanBox;
	@FXML
	private void initialize() throws SQLException {	
		try {
			Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/effortloggerbase", "root", "root");//Establishing connection
			System.out.println("Connected With the database successfully");
			String insertQuery = "SELECT EFFORTLOG FROM table1";
			try (PreparedStatement preparedStatement = connection.prepareStatement(insertQuery); 
					ResultSet resultSet = preparedStatement.executeQuery()) {
                	while (resultSet.next()) {
                		String choice = resultSet.getString("EFFORTLOG");
                		Project.add(choice);
                		}
                		preparedStatement.close();
                		connection.close();
				} catch (SQLException e) {
					e.printStackTrace();
					System.out.println("Error while connecting to the database");
				}
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("Error while connecting to the database");
		}
		ProjectBox.setItems(Project);
		LifeCycleBox.setItems(LifeCycle);
		EffortCategoryBox.setItems(EffortCategory);
		PlanBox.setItems(Plan);
	}
	//Acts as the start button controller while also starting the clock and logging the date and time started
	public void Start(ActionEvent event) throws IOException {
		indexNum++;
		Rectangle1.setFill(Color.GREEN);
		Clock1.setText("Clock is Running");
		startTime = System.currentTimeMillis();
		System.out.print(TimerFormat(startTime));
		try {
			Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/effortloggerbase", "root", "root");//Establishing connection
			System.out.println("Connected With the database successfully");
			String insertQuery = "INSERT INTO table2 (IndexNum, curDate, StartTime) VALUES (?, ?, ?)";
            PreparedStatement preparedStatement = connection.prepareStatement(insertQuery);
            preparedStatement.setString(2 , currentDate());
            preparedStatement.setString(3 , TimerFormat(startTime));

    		int curIndex = getCurrentIndexFromDatabase();
    		preparedStatement.setString(1 , incrementIndex(curIndex));

            preparedStatement.executeUpdate();
            preparedStatement.close();
            connection.close();
			} catch (SQLException e) {
			System.out.println("Error while connecting to the database");
			}
	}
	//Acts as the stop button controller while also entering crucial info into the database
	public void Stop(ActionEvent event) throws IOException {
		Rectangle1.setFill(Color.RED);
		stopTime = System.currentTimeMillis();
		Clock1.setText("Clock is Stopped");
		System.out.print(currentDate());
		System.out.print(TimerFormat(stopTime));
		String choice = ProjectBox.getValue();
		String choice2 = LifeCycleBox.getValue();
		String choice3 = EffortCategoryBox.getValue();
		String choice4 = PlanBox.getValue();
		try {
			Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/effortloggerbase", "root", "root");//Establishing connection
			System.out.println("Connected With the database successfully");

            String insertQuery = "UPDATE table2 SET StopTime=?, TimeDelta=?, LifeCycleStep=?, Category=?, Deliverable=?, EFFORTLOG=? WHERE StartTime=?";
            PreparedStatement preparedStatement = connection.prepareStatement(insertQuery);
            preparedStatement.setString(1 , TimerFormat(stopTime));
            preparedStatement.setString(2 , CalcDelta(startTime, stopTime));
            preparedStatement.setString(3 , choice2);
            preparedStatement.setString(4 , choice3);
            preparedStatement.setString(5 , choice4);
            preparedStatement.setString(6 , choice);
            preparedStatement.setString(7 , TimerFormat(startTime));
            preparedStatement.executeUpdate();
            preparedStatement.close();
            connection.close();
			} catch (SQLException e) {
			System.out.println("Error while connecting to the database");
			}

	}
    private int getCurrentIndexFromDatabase() {
        int currentIndex = 0;
        String choice = ProjectBox.getValue();
        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/effortloggerbase", "root", "root")) {
            String query = "SELECT IndexNum FROM table2 WHERE EFFORTLOG = ? ORDER BY IndexNum DESC LIMIT 1";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setString(1, choice);
                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    if (resultSet.next()) {
                        currentIndex = resultSet.getInt("IndexNum");
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error while connecting to the database");
        }
        return currentIndex;
    }
    
    private String incrementIndex(int currentIndex) {
    	currentIndex++;
    	String Index = Integer.toString(currentIndex);
        return Index;
    }

	//Deletes all entries within the database current testing use
	public void Delete(ActionEvent event) throws IOException {
		try {
			Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/effortloggerbase", "root", "root");//Establishing connection
			System.out.println("Connected With the database successfully");
            String deleteQuery = "DELETE FROM table2";
            PreparedStatement preparedStatement = connection.prepareStatement(deleteQuery);
            int deletedRows = preparedStatement.executeUpdate();
            System.out.println(deletedRows + " entries deleted.");
            preparedStatement.close();
            connection.close();
			} catch (SQLException e) {
			System.out.println("Error while connecting to the database");
			}
	}
	//Formats the times for the items
	private String TimerFormat(long timeLong) {
		long seconds = (timeLong / 1000)%60;
		long minutes = (timeLong / (1000*60)) % 60;
		long hours = (timeLong / (1000*60*60)) % 24;
		String timeFormat = String.format("Time: %02d:%02d:%02d", hours, minutes, seconds);
		return timeFormat;
		
	}
	//Converts time to delta in order to produce amount of effort used
	private String CalcDelta(long start, long stop) {
		float test = (stop-start)/1000;
		float convertSec = test/60;
		//float convertMins = (test / (1000*60))%60;
		String Format = String.format("%.2f",convertSec);
		return Format;
	}
	//Gets the current date and formats it
	private String currentDate() {
		SimpleDateFormat Format = new SimpleDateFormat("yyyy-MM-dd");
		return Format.format(new Date());
		
	}
	
	public void ProceedToEditor(ActionEvent event) throws IOException {
		Parent root = FXMLLoader.load(getClass().getResource("/EffortLoggerEditor.fxml"));
		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	}
	
	public void ProceedToDefect(ActionEvent event) throws IOException {
		Parent root = FXMLLoader.load(getClass().getResource("/DefectConsole.fxml"));
		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	}
	public void ProceedToLogs(ActionEvent event) throws IOException {
		Parent root = FXMLLoader.load(getClass().getResource("/Logs.fxml"));
		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	}
	public void ReturntoStart(ActionEvent event) throws IOException {
		Parent root = FXMLLoader.load(getClass().getResource("/EffortLoggerMainScreen.fxml"));
		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	}
	
	
}
