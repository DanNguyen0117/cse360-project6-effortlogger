package application;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;

public class PokerTableController {
	//Variables
	private Stage stage;
	private Scene scene;
	private Parent root;
	private String access;
	private String Test;
	@FXML
	private Button Select0;
	@FXML
	private Button Select1;
	@FXML
	private Button SelectHalf;
	@FXML
	private Button Select2;
	@FXML
	private Button Select3;
	@FXML
	private Button Select5;
	@FXML
	private Button Select8;
	@FXML
	private Button Select13;
	@FXML
	private Button Select20;
	@FXML
	private Button Select40;
	@FXML
	private Button Select100;
	@FXML
	private Button SelectQues;
	@FXML
	private Button SelectInf;
	@FXML
	private Button Middle;
	@FXML
	private Button Middle2;
	@FXML
	private Label Selected;
	@FXML
	private Label Selected1;
	@FXML
	private Label Center;
	@FXML
	private Label Center2;
	@FXML
	private Button Next;
	@FXML
	private Button Next2;
	@FXML
	private Button Next3;
	@FXML
	private Button Next4;
	@FXML
	private Button Next5;
	@FXML
	private Button Final;
	@FXML
	private Button Finish;
	
	public void nextPlayer(ActionEvent event) throws IOException {
		Parent root = FXMLLoader.load(getClass().getResource("/Final.fxml"));
		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	}
	public void Final(ActionEvent event) throws IOException {
		try {
			Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/effortloggerbase", "root", "root");//Establishing connection
			System.out.println("Connected With the database successfully");
			String insertQuery = "INSERT INTO table4 (PokerCard) VALUES (?)";
            PreparedStatement preparedStatement = connection.prepareStatement(insertQuery);
            preparedStatement.setString(1, Center.getText());
            preparedStatement.executeUpdate();
            preparedStatement.close();
            connection.close();
		} catch (SQLException e) {
			System.out.println("Error while connecting to the database");
			}
	}

	
	public void selectCard0(ActionEvent event) throws IOException {
		Selected.setText("0");
		Selected1.setText("0");
	}
	public void selectCard1(ActionEvent event) throws IOException {
		Selected.setText("1");
		Selected1.setText("1");
	}
	public void selectCardHalf(ActionEvent event) throws IOException {
		Selected.setText("1/2");
		Selected1.setText("1/2");
	}
	public void selectCard2(ActionEvent event) throws IOException {
		Selected.setText("2");
		Selected1.setText("2");
	}
	public void selectCard3(ActionEvent event) throws IOException {
		Selected.setText("3");
		Selected1.setText("3");
	}
	public void selectCard5(ActionEvent event) throws IOException {
		Selected.setText("5");
		Selected1.setText("5");
	}
	public void selectCard8(ActionEvent event) throws IOException {
		Selected.setText("8");
		Selected1.setText("8");
	}
	public void selectCard13(ActionEvent event) throws IOException {
		Selected.setText("13");
		Selected1.setText("13");
	}
	public void selectCard20(ActionEvent event) throws IOException {
		Selected.setText("20");
		Selected1.setText("20");
	}
	public void selectCard40(ActionEvent event) throws IOException {
		Selected.setText("40");
		Selected1.setText("40");
	}
	public void selectCard100(ActionEvent event) throws IOException {
		Selected.setText("100");
		Selected1.setText("100");
	}
	public void selectCardQues(ActionEvent event) throws IOException {
		Selected.setText("?");
		Selected1.setText("?");
	}
	public void selectCardInf(ActionEvent event) throws IOException {
		Selected.setText("∞");
		Selected1.setText("∞");
	}
	public void selectCardCent(ActionEvent event) throws IOException {
		Center.setText(Selected.getText());
	}
	public void selectCardCent2(ActionEvent event) throws IOException {
		Center2.setText(Selected.getText());
	}
}
