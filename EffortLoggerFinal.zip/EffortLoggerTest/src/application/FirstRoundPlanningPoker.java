package application;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class FirstRoundPlanningPoker {
	private Stage stage;
	private Scene scene;
	private Parent root;
	private String access;
	private ObservableList<String> data = FXCollections.observableArrayList();
	@FXML 
	private ChoiceBox<String> projectChoiceBox;
	@FXML
	private TextField description;
	@FXML
	private ChoiceBox<String> historicalItemList;
	@FXML
	private Label storyPoints;
	@FXML
	private Button removeHistoricalItemBtn;
	@FXML
	private Button generateBtn;
	@FXML
	private Button nextRoundBtn;
	@FXML
	private Button importBtn;
	@FXML
	private Button Return;


	public void initialize() {
		try {
			Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/effortloggerbase", "root", "root");//Establishing connection
			System.out.println("Connected With the database successfully");
			String insertQuery = "SELECT EFFORTLOG FROM table1";
			try (PreparedStatement preparedStatement = connection.prepareStatement(insertQuery); 
					ResultSet resultSet = preparedStatement.executeQuery()) {
                	while (resultSet.next()) {
                		String choice = resultSet.getString("EFFORTLOG");
                		data.add(choice);
                		}
                		preparedStatement.close();
                		connection.close();
				} catch (SQLException e) {
					e.printStackTrace();
					System.out.println("Error while connecting to the database");
				}
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("Error while connecting to the database");
		}
		projectChoiceBox.setItems(data);
		historicalItemList.setItems(data);
	}
	
	public void Select(ActionEvent event) {
		String projectName = projectChoiceBox.getValue();
		
	}
	
	public void removeItem(ActionEvent event) {
		if(!historicalItemList.getItems().isEmpty()) {
			int selectedID = historicalItemList.getSelectionModel().getSelectedIndex();
			historicalItemList.getItems().remove(selectedID);
			System.out.println("removed: " + selectedID);
		}
	}

	public void generateStoryPoints(ActionEvent event) {
		int totalPoints = 0;
		try {
			Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/effortloggerbase", "root", "root");//Establishing connection
			System.out.println("Connected With the database successfully");
			String insertQuery = "SELECT PokerCard FROM table4";
			PreparedStatement preparedStatement = connection.prepareStatement(insertQuery);
				try (ResultSet resultSet = preparedStatement.executeQuery()) {
					while (resultSet.next()) {
						int poker = resultSet.getInt("PokerCard");
						totalPoints = totalPoints + poker;
					}
				}
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("Error while connecting to the database");
		}
		storyPoints.setText(String.valueOf(totalPoints));
		
	}

	public void nextRoundBtnPushed(ActionEvent event) throws IOException {
			try {
				Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/effortloggerbase", "root", "root");//Establishing connection
				System.out.println("Connected With the database successfully");
				String insertQuery = "INSERT INTO table4 (Average, UserStory, Project) VALUES (?, ?, ?)";
				PreparedStatement preparedStatement = connection.prepareStatement(insertQuery);
				preparedStatement.setString(1, storyPoints.getText());
				preparedStatement.setString(2, description.getText());
				preparedStatement.setString(3, projectChoiceBox.getValue());
				int rowsAffected = preparedStatement.executeUpdate();
				System.out.println(rowsAffected + " row(s) updated.");
			
		
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("Error while connecting to the database");
		}
			Parent root = FXMLLoader.load(getClass().getResource("/PokerTable2.fxml"));
			stage = (Stage)((Node)event.getSource()).getScene().getWindow();
			scene = new Scene(root);
			stage.setScene(scene);
			stage.show();
	}
	public void ReturntoStart(ActionEvent event) throws IOException {
		Parent root = FXMLLoader.load(getClass().getResource("/EffortLoggerMainScreen.fxml"));
		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	}
}
	
