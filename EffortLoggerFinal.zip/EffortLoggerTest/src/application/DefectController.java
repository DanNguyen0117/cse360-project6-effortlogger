package application;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.util.Duration;

public class DefectController {
	private Stage stage;
	private Scene scene;
	private Parent root;
	private String access;
	private String NewDefect;
	private String currentIndex;
	private String EffortProject;
	private ObservableList<String> data = FXCollections.observableArrayList();
	private ObservableList<String> names = FXCollections.observableArrayList();
	private ObservableList<String> inject = FXCollections.observableArrayList("Problem Understanding", "Conceptual Design Plan", "Requirements", "Conceptual Design", "Conceptual Design Review", "Detailed Design Plan", "Detailed Design/Prototype", "Detailed Design Review", "Implementation Plan", "Test Case Generation", "Solution Specification", "Solution Review", "Solution Implementation", "Unit/System Test", "Reflection", "Repository Update", "Planning", "Information Gathering", "Information Understanding", "Verifying", "Outlining", "Drafting", "Finalizing", "Team Meeting", "Coach Meeting", "Stakeholder Meeting");
	private ObservableList<String> defect = FXCollections.observableArrayList("Not specified", "Documentation", "Syntax", "Build", "Package", "Assignment", "Interface", "Checking", "Data", "Function", "System", "Environment");
	@FXML
	private Button Create;
	@FXML
	private Button Delete;
	@FXML
	private Button Clear;
	@FXML
	private Button Select;
	@FXML
	private Button Select1;
	@FXML
	private Button Update;
	@FXML
	private Button Close;
	@FXML
	private Label Saved;
	@FXML
	private Button Reopen;
	@FXML
	private ChoiceBox<String> ProjectBox;
	@FXML
	private ChoiceBox<String> Fix;
	@FXML
	private ChoiceBox<String> NameBox;
	@FXML
	private ChoiceBox<String> Injected;
	@FXML
	private ChoiceBox<String> Injected2;
	@FXML
	private ChoiceBox<String> DefCat;
	@FXML
	private TextField Name;
	@FXML
	private TextField Detail;
	@FXML
	private Label Num;
	@FXML
	private Label Status;
	@FXML
	private void initialize() {	
		try {
			Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/effortloggerbase", "root", "root");//Establishing connection
			System.out.println("Connected With the database successfully");
			String insertQuery = "SELECT EFFORTLOG FROM table1";
			 try (PreparedStatement preparedStatement = connection.prepareStatement(insertQuery);
	                 ResultSet resultSet = preparedStatement.executeQuery()) {
	                while (resultSet.next()) {
	                    String choice = resultSet.getString("EFFORTLOG");
	                    data.add(choice);
	                }
	                preparedStatement.close();
	                connection.close();
	            }
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("Error while connecting to the database");
			}
		if (data != null) {
			ProjectBox.setItems(data);
		}
		Injected.setItems(inject);
		Injected2.setItems(inject);
		DefCat.setItems(defect);
		
		
	}
	private void UpdateEntries(String selectedValue){ 
		NameBox.getItems().clear();
		Fix.getItems().clear();
		ObservableList<String> items = entriesFromDatabase(selectedValue);
		NameBox.setItems(items);
		Fix.setItems(items);
		
	}
	private ObservableList<String> entriesFromDatabase(String selectedValue) {
		names.add("-- no defect selected --");
		try {
			Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/effortloggerbase", "root", "root");//Establishing connection
			System.out.println("Connected With the database successfully");
			String query = "SELECT Number, Name FROM table2 WHERE EFFORTLOG = ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setString(1, selectedValue);
                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    while (resultSet.next()) {
                    	if (resultSet.getString("Number") != null) {
                    		String value = resultSet.getString("Number");
                    		String value2 = resultSet.getString("Name");
                    		String formatted = value + ". " + value2;
                    		names.add(formatted);
                    	}
                    }
                }
                preparedStatement.close();
		        connection.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error while connecting to the database");
        }
		
        return names;
    }
	public void Select(ActionEvent event) throws IOException {
		UpdateEntries(ProjectBox.getValue());
		EffortProject = ProjectBox.getValue();
		NameBox.setValue("-- no defect selected --");
		
	}
	
	public void Select1(ActionEvent event) throws IOException {
		try {
			Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/effortloggerbase", "root", "root");//Establishing connection
			System.out.println("Connected With the database successfully");
			String insertQuery = "SELECT Number, Name, Detail, Injected, Removed, Status, EFFORTLOG, Fix FROM table2 WHERE Number = ?";
			PreparedStatement preparedStatement = connection.prepareStatement(insertQuery);
			char indexnum = NameBox.getValue().charAt(0);
			String indexnumStr = String.valueOf(indexnum);
			currentIndex = indexnumStr;
			preparedStatement.setString(1, indexnumStr);
			try (ResultSet resultSet = preparedStatement.executeQuery()) {
                while (resultSet.next()) {
                	Num.setText(resultSet.getString("Number"));
                	Name.setText(resultSet.getString("Name"));
                	Detail.setText(resultSet.getString("Detail"));
                	Injected.setValue(resultSet.getString("Injected"));
                	Injected2.setValue(resultSet.getString("Removed"));
                	Status.setText("Status: " + resultSet.getString("Status"));
                	EffortProject = resultSet.getString("EFFORTLOG");
                	Fix.setValue(resultSet.getString("Fix"));
                }
			}
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error while connecting to the database");
        }	
	}
	
    private String incrementIndex(int currentIndex) {
    	currentIndex++;
    	String Index = Integer.toString(currentIndex);
        return Index;
    }
    
    private int getCurrentIndexFromDatabase() {
        int currentIndex = 0;
        String choice = ProjectBox.getValue();
        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/effortloggerbase", "root", "root")) {
            String query = "SELECT Number FROM table2 WHERE EFFORTLOG = ? ORDER BY Number DESC LIMIT 1";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setString(1, choice);
                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    if (resultSet.next()) {
                        currentIndex = resultSet.getInt("Number");
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error while connecting to the database");
        }
        return currentIndex;
    }
	
	public void Create(ActionEvent event) throws IOException {
		try {
			Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/effortloggerbase", "root", "root");//Establishing connection
			System.out.println("Connected With the database successfully");
			String insertQuery = "INSERT INTO table2 (EFFORTLOG, Number, Name, Status) VALUES (?, ?, ?, ?)";
			PreparedStatement preparedStatement = connection.prepareStatement(insertQuery);
			int curIndex = getCurrentIndexFromDatabase();
			String DefectData = Name.getText();
			preparedStatement.setString(1, EffortProject);
			preparedStatement.setString(2, incrementIndex(curIndex));
			preparedStatement.setString(3, DefectData);
			preparedStatement.setString(4, "Open");
			preparedStatement.executeUpdate();
			System.out.println("Data inserted successfully!");
		    preparedStatement.close();
		    connection.close();
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("Error while connecting to the database");
			}
		UpdateEntries(ProjectBox.getValue());
	}
	public void Update(ActionEvent event) throws IOException {
		try {
			Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/effortloggerbase", "root", "root");//Establishing connection
			System.out.println("Connected With the database successfully");
			String insertQuery = "UPDATE table2 SET Name = ?, Detail = ?, Injected = ?, Removed = ?, DefCat = ?, Fix = ? WHERE Number = ? AND EFFORTLOG = ?";
			PreparedStatement preparedStatement = connection.prepareStatement(insertQuery);
			preparedStatement.setString(1, Name.getText());
			preparedStatement.setString(2, Detail.getText());
			preparedStatement.setString(3, Injected.getValue());
			preparedStatement.setString(4, Injected2.getValue());
			preparedStatement.setString(5, DefCat.getValue());
			preparedStatement.setString(6, Fix.getValue());
			preparedStatement.setString(7, currentIndex);
			preparedStatement.setString(8, EffortProject);
			int rowsAffected = preparedStatement.executeUpdate();
			System.out.println(rowsAffected + " row(s) updated.");
			Saved.setStyle("-fx-background-color: green;");
			Timeline timeline = new Timeline(
		            new KeyFrame(Duration.seconds(1), e -> {
		                Saved.setStyle("-fx-background-color: transparent;");
		            })
		    );
		    timeline.play();
			UpdateEntries(ProjectBox.getValue());
			Name.setText("");
			Detail.setText("");
			Injected.setValue("");
			Injected2.setValue("");
			DefCat.setValue("");
			Fix.setValue("");
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error while connecting to the database");
        }
	}
	public void Close(ActionEvent event) throws IOException {
		try {
			Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/effortloggerbase", "root", "root");//Establishing connection
			System.out.println("Connected With the database successfully");
			String insertQuery = "UPDATE table2 SET Status = ? WHERE Number = ? AND EFFORTLOG = ?";
			PreparedStatement preparedStatement = connection.prepareStatement(insertQuery);
			preparedStatement.setString(1, "Closed");
			preparedStatement.setString(2, currentIndex);
			preparedStatement.setString(3, EffortProject);
			int rows = preparedStatement.executeUpdate();
			System.out.println(rows + " row(s) updated.");
		} catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error while connecting to the database");
        }
		Status.setText("Status: Closed");
	}
	public void Reopen(ActionEvent event) throws IOException {
		try {
			Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/effortloggerbase", "root", "root");//Establishing connection
			System.out.println("Connected With the database successfully");
			String insertQuery = "UPDATE table2 SET Status = ? WHERE Number = ? AND EFFORTLOG = ?";
			PreparedStatement preparedStatement = connection.prepareStatement(insertQuery);
			preparedStatement.setString(1, "Open");
			preparedStatement.setString(2, currentIndex);
			preparedStatement.setString(3, EffortProject);
			int rows = preparedStatement.executeUpdate();
			System.out.println(rows + " row(s) updated.");
		} catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error while connecting to the database");
        }
		Status.setText("Status: Open");
	}
	public void Delete(ActionEvent event) throws IOException {
		try {
			Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/effortloggerbase", "root", "root");//Establishing connection
			System.out.println("Connected With the database successfully");
			String insertQuery = "DELETE FROM table2 WHERE Number = ? AND EFFORTLOG = ?";
			char indexnum = NameBox.getValue().charAt(0);
			String indexnumStr = String.valueOf(indexnum);
			currentIndex = indexnumStr;
			System.out.print(currentIndex);
			System.out.print(EffortProject);
			try (PreparedStatement preparedStatement = connection.prepareStatement(insertQuery)) {
				preparedStatement.setString(1, currentIndex);
				preparedStatement.setString(2, EffortProject);
                preparedStatement.executeUpdate();
                UpdateEntries(ProjectBox.getValue());
    			Name.setText("");
    			Detail.setText("");
    			Injected.setValue("");
    			Injected2.setValue("");
    			DefCat.setValue("");
    			Fix.setValue("");
            }
            connection.close();
		} catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error while connecting to the database");
        }
	}
	public void Clear(ActionEvent event) throws IOException {
		try {
			Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/effortloggerbase", "root", "root");//Establishing connection
			System.out.println("Connected With the database successfully");
            String deleteQuery = "DELETE FROM table2 WHERE EFFORTLOG = ? AND Status IS NOT NULL";
            PreparedStatement preparedStatement = connection.prepareStatement(deleteQuery);
            System.out.println(EffortProject);
            preparedStatement.setString(1, EffortProject);
            int deletedRows = preparedStatement.executeUpdate();
            System.out.println(deletedRows + " entries deleted.");
            preparedStatement.close();
            connection.close();
			} catch (SQLException e) {
			System.out.println("Error while connecting to the database");
			}
	}
	public void Return(ActionEvent event) throws IOException {
		Parent root = FXMLLoader.load(getClass().getResource("/EffortLogger1.fxml"));
		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	}
}
