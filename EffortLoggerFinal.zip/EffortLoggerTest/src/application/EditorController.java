package application;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.util.Duration;

public class EditorController {
	private Stage stage;
	private Scene scene;
	private Parent root;
	private String access;
	private String currentIndex;
	private String EffortProject;
	private ObservableList<String> data = FXCollections.observableArrayList();
	private ObservableList<String> entries = FXCollections.observableArrayList();
	private ObservableList<String> categories = FXCollections.observableArrayList("Plans","Deliverables","Interuptions","Defects","Others");
	private ObservableList<String> cycle = FXCollections.observableArrayList("Planning","Information Gathering","Information Understanding", "Verifying", "Outlining", "Drafting", "Finalizing", "Team Meeting", "Coach Meeting", "Stakeholder Meeting");
	private ObservableList<String> plans = FXCollections.observableArrayList("Project Plan","Risk Management Plan","Conceptual Design Plan", "Detailed Design Plan", "Implementation Plan");
	@FXML
	private ChoiceBox<String> Project;
	@FXML
	private TextField NewProject;
	@FXML
	private TextField Date;
	@FXML
	private TextField StartTime;
	@FXML
	private TextField StopTime;
	@FXML
	private ChoiceBox<String> EffortCat;
	@FXML
	private ChoiceBox<String> LifeCycle;
	@FXML
	private ChoiceBox<String> Plan;
	@FXML
	private Button CreateNew;
	@FXML
	private Button ClearEffort;
	@FXML
	private Button Select;
	@FXML
	private Button Select1;
	@FXML
	private ChoiceBox<String> EntryBox;
	@FXML
	private Button Update;
	@FXML
	private Label Saved;
	@FXML
	private Button Delete;
	@FXML
	private Button Return;
	@FXML
	private void initialize() {	
		try {
			Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/effortloggerbase", "root", "root");//Establishing connection
			System.out.println("Connected With the database successfully");
			String insertQuery = "SELECT EFFORTLOG FROM table1";
			 try (PreparedStatement preparedStatement = connection.prepareStatement(insertQuery);
	                 ResultSet resultSet = preparedStatement.executeQuery()) {
	                while (resultSet.next()) {
	                    String choice = resultSet.getString("EFFORTLOG");
	                    data.add(choice);
	                }
	                preparedStatement.close();
	                connection.close();
	            }
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("Error while connecting to the database");
			}
		Project.setItems(data);
	}
	
	private void UpdateEntries(String selectedValue){ 
		EntryBox.getItems().clear();
		ObservableList<String> items = entriesFromDatabase(selectedValue);
		EntryBox.setItems(items);
		
	}
	
	private ObservableList<String> entriesFromDatabase(String selectedValue) {
		try {
			Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/effortloggerbase", "root", "root");//Establishing connection
			System.out.println("Connected With the database successfully");
			String query = "SELECT IndexNum, CurDate, StartTime, StopTime, LifeCycleStep, Category, Deliverable FROM table2 WHERE EFFORTLOG = ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setString(1, selectedValue);
                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    while (resultSet.next()) {
                    	String value = resultSet.getString("IndexNum");
                    	String value2 = resultSet.getString("CurDate");
                    	String value3 = resultSet.getString("StartTime");
                    	String value4 = resultSet.getString("StopTime");
                    	String value5 = resultSet.getString("LifeCycleStep");
                    	String value6 = resultSet.getString("Category");
                    	String value7 = resultSet.getString("Deliverable");
                    	String formatted = value + ". " + value2 + " (" + value3 + "-" + value4 + ") " + value5 + "; " + value6 + "; " + value7;
                        entries.add(formatted);
                        
                    }
                }
                preparedStatement.close();
		        connection.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error while connecting to the database");
        }
		
        return entries;
    }
	
	
	public void Create(ActionEvent event) throws IOException {
		try {
			Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/effortloggerbase", "root", "root");//Establishing connection
			System.out.println("Connected With the database successfully");
			String insertQuery = "INSERT INTO table1 (EFFORTLOG) VALUES (?)";
			PreparedStatement preparedStatement = connection.prepareStatement(insertQuery);
				 String ProjectData = NewProject.getText();
				 preparedStatement.setString(1, ProjectData);
				 preparedStatement.executeUpdate();
				 System.out.println("Data inserted successfully!");
		         preparedStatement.close();
		         connection.close();
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("Error while connecting to the database");
			}
	}
	
	public void Select(ActionEvent event) throws IOException {
		UpdateEntries(Project.getValue());
		EffortProject = Project.getValue();
	}
	
	public void Select1(ActionEvent event) throws IOException {
		try {
			Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/effortloggerbase", "root", "root");//Establishing connection
			System.out.println("Connected With the database successfully");
			String insertQuery = "SELECT curDate, StartTime, StopTime, LifeCycleStep, Category, Deliverable, EFFORTLOG FROM table2 WHERE IndexNum = ?";
			PreparedStatement preparedStatement = connection.prepareStatement(insertQuery);
			char indexnum = EntryBox.getValue().charAt(0);
			String indexnumStr = String.valueOf(indexnum);
			currentIndex = indexnumStr;
			preparedStatement.setString(1, indexnumStr);
			try (ResultSet resultSet = preparedStatement.executeQuery()) {
                while (resultSet.next()) {
                	Date.setText(resultSet.getString("curDate"));
                	StartTime.setText(resultSet.getString("StartTime"));
                	StopTime.setText(resultSet.getString("StopTime"));
                	LifeCycle.setValue(resultSet.getString("LifeCycleStep"));
                	EffortCat.setValue(resultSet.getString("Category"));
                	Plan.setValue(resultSet.getString("Deliverable"));
                	EffortProject = resultSet.getString("EFFORTLOG");
                }
			}
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error while connecting to the database");
        }
		LifeCycle.setItems(cycle);
		EffortCat.setItems(categories);
		Plan.setItems(plans);	
	}
	
	public void Update(ActionEvent event) throws IOException {
		try {
			Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/effortloggerbase", "root", "root");//Establishing connection
			System.out.println("Connected With the database successfully");
			String insertQuery = "UPDATE table2 SET curDate = ?, StartTime = ?, StopTime = ?, LifeCycleStep = ?, Category = ?, Deliverable = ? WHERE IndexNum = ? AND EFFORTLOG = ?";
			PreparedStatement preparedStatement = connection.prepareStatement(insertQuery);
			preparedStatement.setString(1, Date.getText());
			preparedStatement.setString(2, StartTime.getText());
			preparedStatement.setString(3, StopTime.getText());
			preparedStatement.setString(4, LifeCycle.getValue());
			preparedStatement.setString(5, EffortCat.getValue());
			preparedStatement.setString(6, Plan.getValue());
			preparedStatement.setString(7, currentIndex);
			preparedStatement.setString(8, EffortProject);
			int rowsAffected = preparedStatement.executeUpdate();
			System.out.println(rowsAffected + " row(s) updated.");
			Saved.setStyle("-fx-background-color: green;");
			Timeline timeline = new Timeline(
		            new KeyFrame(Duration.seconds(1), e -> {
		                Saved.setStyle("-fx-background-color: transparent;");
		            })
		    );
		    timeline.play();
			UpdateEntries(Project.getValue());
			LifeCycle.setValue("");
			EffortCat.setValue("");
			Plan.setValue("");
			Date.clear(); 
			StartTime.clear(); 
			StopTime.clear(); 
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error while connecting to the database");
        }
	}
	
	public void Delete(ActionEvent event) throws IOException {
		try {
			Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/effortloggerbase", "root", "root");//Establishing connection
			System.out.println("Connected With the database successfully");
			String insertQuery = "DELETE FROM table2 WHERE IndexNum = ? AND EFFORTLOG = ?";
			char indexnum = EntryBox.getValue().charAt(0);
			String indexnumStr = String.valueOf(indexnum);
			currentIndex = indexnumStr;
			System.out.print(currentIndex);
			System.out.print(EffortProject);
			try (PreparedStatement preparedStatement = connection.prepareStatement(insertQuery)) {
				preparedStatement.setString(1, currentIndex);
				preparedStatement.setString(2, EffortProject);
                preparedStatement.executeUpdate();
                UpdateEntries(Project.getValue());
    			LifeCycle.setValue("");
    			EffortCat.setValue("");
    			Plan.setValue("");
    			Date.clear(); 
    			StartTime.clear(); 
    			StopTime.clear();
            }
            connection.close();
		} catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error while connecting to the database");
        }
	}
	
	public void Return(ActionEvent event) throws IOException {
		Parent root = FXMLLoader.load(getClass().getResource("/EffortLogger1.fxml"));
		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	}
	
	public void Clear(ActionEvent event) throws IOException {
		try {
			Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/effortloggerbase", "root", "root");//Establishing connection
			System.out.println("Connected With the database successfully");
            String deleteQuery = "DELETE FROM table2 WHERE EFFORTLOG = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(deleteQuery);
            System.out.println(EffortProject);
            preparedStatement.setString(1, EffortProject);
            int deletedRows = preparedStatement.executeUpdate();
            System.out.println(deletedRows + " entries deleted.");
            preparedStatement.close();
            connection.close();
			} catch (SQLException e) {
			System.out.println("Error while connecting to the database");
			}
	}
	
}
