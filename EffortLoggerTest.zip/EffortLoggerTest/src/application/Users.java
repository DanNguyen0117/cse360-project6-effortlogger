package application;

public class Users {
	int data;
	public boolean access;

} 

