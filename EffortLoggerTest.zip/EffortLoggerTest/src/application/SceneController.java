package application;

import java.io.IOException;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class SceneController {

	private Stage stage;
	private Scene scene;
	private Parent root;
	private String access;
	@FXML
	private Label myLabel;
	@FXML
	private TextField myTextField;
	@FXML
	private TextField pasTextField;
	@FXML
	private Button myButton;


	
	//Calls the switchToScene2 function
	public void switchToScene1(ActionEvent event) throws IOException {
		switchToScene2(event);
	}
	//Checks they type of user and if the password is correct
	public void switchToScene2(ActionEvent event) throws IOException {
		//Checks if the correct username and password have been input for the Employee role 
		if (myTextField.getText().toString().equals("Employee") && pasTextField.getText().toString().equals("password")) { 
			Parent root = FXMLLoader.load(getClass().getResource("/EffortLoggerMainScreen.fxml"));
			stage = (Stage)((Node)event.getSource()).getScene().getWindow();
			scene = new Scene(root);
			stage.setScene(scene);
			stage.show();
		//Checks if the correct username and password have been input for the Employee role
		} else if (myTextField.getText().toString().equals("Supervisor") && pasTextField.getText().toString().equals("password")) {
			Parent root = FXMLLoader.load(getClass().getResource("/Supervisor.fxml"));
			stage = (Stage)((Node)event.getSource()).getScene().getWindow();
			scene = new Scene(root);
			stage.setScene(scene);
			stage.show();
		//Checks if no input has been given in a login attempt
		} else if (myTextField.getText().isEmpty() && pasTextField.getText().isEmpty()) {
			myLabel.setText("Please enter your credentials");
		//Checks if the username and/or password is incorrect.
		} else {
			myLabel.setText("Wrong Username and Password");
			
		}
	}
}

